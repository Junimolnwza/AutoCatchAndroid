/*
 * Auto Catch Android - No Harmony Edition
 *
 * ทำงานบน Android ได้เพราะ:
 *   - ไม่ใช้ Harmony patch เลย
 *   - ใช้แค่ SMAPI UpdateTicked event
 *   - เข้าถึง BobberBar fields ผ่าน Reflection (ซึ่ง SMAPI สามารถ rewrite ได้)
 */

using System.Reflection;
using StardewModdingAPI;
using StardewModdingAPI.Events;
using StardewValley;
using StardewValley.Menus;

namespace AutoCatch
{
    public class ModEntry : Mod
    {
        // Cache field references so we only look them up once
        private FieldInfo? _distanceFromCatching;
        private FieldInfo? _bobberBarPos;
        private FieldInfo? _bobberBarHeight;
        private FieldInfo? _bobberPosition;
        private FieldInfo? _perfect;
        private FieldInfo? _treasureCaught;
        private FieldInfo? _treasure;

        private bool _fieldsReady = false;

        public override void Entry(IModHelper helper)
        {
            helper.Events.GameLoop.GameLaunched += OnGameLaunched;
            helper.Events.GameLoop.UpdateTicked  += OnUpdateTicked;
        }

        // Look up BobberBar fields after game is fully loaded
        private void OnGameLaunched(object? sender, GameLaunchedEventArgs e)
        {
            var t = typeof(BobberBar);

            _distanceFromCatching = t.GetField("distanceFromCatching",
                BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
            _bobberBarPos = t.GetField("bobberBarPos",
                BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
            _bobberBarHeight = t.GetField("bobberBarHeight",
                BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
            _bobberPosition = t.GetField("bobberPosition",
                BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
            _perfect = t.GetField("perfect",
                BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
            _treasureCaught = t.GetField("treasureCaught",
                BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
            _treasure = t.GetField("treasure",
                BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);

            // Only need the essential fields to work
            if (_distanceFromCatching != null)
            {
                _fieldsReady = true;
                Monitor.Log("Auto Catch Android: fields found, mod ready!", LogLevel.Info);
            }
            else
            {
                Monitor.Log("Auto Catch Android: WARNING - could not find BobberBar fields. " +
                            "The mod may not work on this game version.", LogLevel.Warn);
            }
        }

        private void OnUpdateTicked(object? sender, UpdateTickedEventArgs e)
        {
            if (!_fieldsReady) return;
            if (!Context.IsWorldReady) return;
            if (Game1.activeClickableMenu is not BobberBar bobber) return;

            AutoWin(bobber);
        }

        private void AutoWin(BobberBar bobber)
        {
            try
            {
                // Fill the catch meter to 100%
                _distanceFromCatching?.SetValue(bobber, 1f);

                // Centre the bar on the fish so "perfect" bar is valid
                if (_bobberPosition != null && _bobberBarHeight != null && _bobberBarPos != null)
                {
                    float fishPos   = (float)(_bobberPosition.GetValue(bobber) ?? 0f);
                    float barHeight = (float)(_bobberBarHeight.GetValue(bobber) ?? 96f);
                    _bobberBarPos.SetValue(bobber, fishPos - barHeight / 2f);
                }

                // Perfect catch
                _perfect?.SetValue(bobber, true);

                // Auto-collect treasure chest
                bool hasTreasure = (bool)(_treasure?.GetValue(bobber) ?? false);
                if (hasTreasure)
                {
                    _treasureCaught?.SetValue(bobber, true);
                }
            }
            catch (Exception ex)
            {
                Monitor.Log($"Auto Catch error: {ex.Message}", LogLevel.Error);
            }
        }
    }
}
